'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard,
  Users,
  Mail,
  FileText,
  BarChart3,
  Settings,
  ChevronDown,
  Building2,
} from 'lucide-react'
import { useState } from 'react'

const navItems = [
  { 
    href: '/dashboard', 
    label: '대시보드', 
    icon: LayoutDashboard 
  },
  { 
    href: '/clients', 
    label: '고객관리', 
    icon: Users,
    children: [
      { href: '/clients', label: '전체 목록' },
      { href: '/clients/kanban', label: '칸반 보드' },
    ]
  },
  { 
    href: '/email', 
    label: '이메일', 
    icon: Mail,
    children: [
      { href: '/email/compose', label: '발송' },
      { href: '/email/templates', label: '템플릿' },
    ]
  },
  { href: '/proposals', label: '제안서', icon: FileText },
  { 
    href: '/analytics', 
    label: '분석', 
    icon: BarChart3,
    children: [
      { href: '/analytics/failure', label: '실패 분석' },
      { href: '/analytics/reports', label: '리포트' },
    ]
  },
  { href: '/settings', label: '설정', icon: Settings },
]

export function Sidebar() {
  const pathname = usePathname()
  const [openMenus, setOpenMenus] = useState<string[]>([])

  const toggleMenu = (href: string) => {
    setOpenMenus(prev => 
      prev.includes(href) 
        ? prev.filter(h => h !== href)
        : [...prev, href]
    )
  }

  const isActive = (href: string) => {
    if (href === '/clients' && pathname === '/clients') return true
    if (href === '/clients/kanban' && pathname === '/clients/kanban') return true
    return pathname.startsWith(href) && href !== '/clients'
  }

  return (
    <aside className="w-64 bg-slate-900 text-white min-h-screen p-4 flex flex-col">
      {/* 로고 */}
      <div className="flex items-center gap-2 px-2 py-4 mb-6">
        <Building2 className="h-8 w-8 text-blue-400" />
        <div>
          <h1 className="font-bold text-lg">MSBENTER</h1>
          <p className="text-xs text-slate-400">영업 에이전트</p>
        </div>
      </div>

      {/* 네비게이션 */}
      <nav className="flex-1 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon
          const hasChildren = item.children && item.children.length > 0
          const isOpen = openMenus.includes(item.href)
          const active = isActive(item.href)

          return (
            <div key={item.href}>
              {hasChildren ? (
                <>
                  <button
                    onClick={() => toggleMenu(item.href)}
                    className={cn(
                      'w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-colors',
                      active 
                        ? 'bg-slate-800 text-white' 
                        : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="h-5 w-5" />
                      <span>{item.label}</span>
                    </div>
                    <ChevronDown 
                      className={cn(
                        'h-4 w-4 transition-transform',
                        isOpen && 'rotate-180'
                      )} 
                    />
                  </button>
                  {isOpen && (
                    <div className="ml-8 mt-1 space-y-1">
                      {item.children.map((child) => (
                        <Link
                          key={child.href}
                          href={child.href}
                          className={cn(
                            'block px-3 py-2 rounded-lg text-sm transition-colors',
                            pathname === child.href
                              ? 'bg-slate-700 text-white'
                              : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                          )}
                        >
                          {child.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <Link
                  href={item.href}
                  className={cn(
                    'flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors',
                    active 
                      ? 'bg-slate-800 text-white' 
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  )}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </Link>
              )}
            </div>
          )
        })}
      </nav>

      {/* 하단 사용자 정보 (추후 구현) */}
      <div className="border-t border-slate-700 pt-4 mt-4">
        <div className="flex items-center gap-3 px-3 py-2">
          <div className="h-8 w-8 rounded-full bg-slate-700 flex items-center justify-center">
            <span className="text-sm font-medium">김</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">김영업</p>
            <p className="text-xs text-slate-400 truncate">sales@msbenter.com</p>
          </div>
        </div>
      </div>
    </aside>
  )
}
