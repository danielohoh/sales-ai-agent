import { MainLayout } from '@/components/layout'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Users, 
  TrendingUp, 
  AlertCircle, 
  CheckCircle2,
  Phone,
  Mail,
  Calendar,
} from 'lucide-react'

// 임시 데이터 (추후 Supabase에서 가져올 예정)
const stats = [
  { label: '전체 고객', value: '127', icon: Users, change: '+12%' },
  { label: '이번 달 신규', value: '18', icon: TrendingUp, change: '+5' },
  { label: '진행 중', value: '24', icon: AlertCircle, change: '3건 주의' },
  { label: '계약 완료', value: '8', icon: CheckCircle2, change: '이번 달' },
]

const reminders = [
  { type: 'urgent', icon: '🔴', label: '3일 미연락', client: 'ABC프랜차이즈', contact: '김철수' },
  { type: 'urgent', icon: '🔴', label: '3일 미연락', client: 'XYZ치킨', contact: '이영희' },
  { type: 'warning', icon: '🟡', label: '7일 무응답', client: '델리버리코리아', contact: '박민수' },
  { type: 'info', icon: '📅', label: '내일 미팅', client: '푸드테크', contact: '최지현' },
]

const recentActivities = [
  { type: 'call', icon: Phone, description: 'ABC프랜차이즈 통화 완료', time: '10분 전' },
  { type: 'email', icon: Mail, description: 'XYZ치킨 제안서 발송', time: '1시간 전' },
  { type: 'meeting', icon: Calendar, description: '델리버리코리아 미팅 예약', time: '2시간 전' },
]

const missedOpportunities = [
  { company: 'ABC프랜차이즈', stage: '검토', days: 21, lastActivity: '견적서 발송' },
  { company: 'XYZ치킨', stage: '메일전송', days: 14, lastActivity: '소개자료 발송' },
  { company: '델리버리코리아', stage: '미팅후', days: 10, lastActivity: '미팅 완료' },
]

export default function DashboardPage() {
  return (
    <MainLayout title="대시보드">
      <div className="space-y-6">
        {/* 오늘의 리마인더 */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">🔔 오늘의 리마인더</CardTitle>
              <a href="#" className="text-sm text-blue-600 hover:underline">전체보기</a>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {reminders.map((item, index) => (
                <div 
                  key={index} 
                  className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 cursor-pointer"
                >
                  <span>{item.icon}</span>
                  <span className="text-sm font-medium">{item.label}:</span>
                  <span className="text-sm text-slate-600">
                    {item.client} - {item.contact}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* 통계 카드 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-500">{stat.label}</p>
                      <p className="text-2xl font-bold mt-1">{stat.value}</p>
                      <p className="text-xs text-green-600 mt-1">{stat.change}</p>
                    </div>
                    <div className="h-12 w-12 rounded-full bg-blue-50 flex items-center justify-center">
                      <Icon className="h-6 w-6 text-blue-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 최근 활동 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">최근 활동</CardTitle>
              <CardDescription>오늘의 영업 활동 기록</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity, index) => {
                  const Icon = activity.icon
                  return (
                    <div key={index} className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center">
                        <Icon className="h-5 w-5 text-slate-600" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{activity.description}</p>
                        <p className="text-xs text-slate-500">{activity.time}</p>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* 놓치고 있는 고객 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">⚠️ 놓치고 있는 고객</CardTitle>
              <CardDescription>장기간 진행되지 않는 고객</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {missedOpportunities.map((item, index) => (
                  <div 
                    key={index} 
                    className="flex items-center justify-between p-3 rounded-lg bg-slate-50 hover:bg-slate-100 cursor-pointer"
                  >
                    <div>
                      <p className="font-medium text-sm">{item.company}</p>
                      <p className="text-xs text-slate-500">마지막: {item.lastActivity}</p>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline">{item.stage}</Badge>
                      <p className="text-xs text-red-500 mt-1">{item.days}일 경과</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 파이프라인 현황 - 차트 영역 (추후 Recharts로 구현) */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">📈 파이프라인 현황</CardTitle>
            <CardDescription>영업 단계별 고객 분포</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center bg-slate-50 rounded-lg">
              <p className="text-slate-400">차트 영역 (Recharts 연동 예정)</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  )
}
