import { PipelineStage, InquirySource, FailureCategory, ActivityType } from '@/types'

// 파이프라인 단계 정보
export const PIPELINE_STAGES: Record<PipelineStage, { label: string; color: string; order: number }> = {
  inquiry: { label: '문의접수', color: 'bg-gray-500', order: 1 },
  called: { label: '전화완료', color: 'bg-blue-500', order: 2 },
  email_sent: { label: '메일전송', color: 'bg-indigo-500', order: 3 },
  meeting: { label: '미팅', color: 'bg-purple-500', order: 4 },
  meeting_followup: { label: '미팅후메일', color: 'bg-pink-500', order: 5 },
  reviewing: { label: '검토', color: 'bg-yellow-500', order: 6 },
  failed: { label: '실패', color: 'bg-red-500', order: 7 },
  on_hold: { label: '보류', color: 'bg-orange-500', order: 8 },
  in_progress: { label: '계약진행중', color: 'bg-cyan-500', order: 9 },
  completed: { label: '계약완료', color: 'bg-green-500', order: 10 },
}

// 칸반 보드에 표시할 단계 (순서대로)
export const KANBAN_STAGES: PipelineStage[] = [
  'inquiry',
  'called',
  'email_sent',
  'meeting',
  'meeting_followup',
  'reviewing',
  'in_progress',
  'completed',
]

// 종료 단계 (칸반에서 별도 처리)
export const END_STAGES: PipelineStage[] = ['failed', 'on_hold']

// 문의 경로 정보
export const INQUIRY_SOURCES: Record<InquirySource, { label: string }> = {
  website: { label: '홈페이지' },
  phone: { label: '전화' },
  referral: { label: '소개' },
  exhibition: { label: '전시회' },
  other: { label: '기타' },
}

// 실패 카테고리 정보
export const FAILURE_CATEGORIES: Record<FailureCategory, { label: string; description: string }> = {
  price: { label: '가격', description: '비용, 예산, ROI 관련' },
  timing: { label: '타이밍', description: '도입 시기, 내부 일정' },
  competitor: { label: '경쟁사', description: '경쟁사 선택' },
  internal: { label: '내부사정', description: '조직 변경, 의사결정 지연' },
  feature: { label: '기능', description: '기능 부족/불일치' },
  other: { label: '기타', description: '기타 사유' },
}

// 활동 유형 정보
export const ACTIVITY_TYPES: Record<ActivityType, { label: string; icon: string }> = {
  call: { label: '통화', icon: '📞' },
  email_sent: { label: '이메일 발송', icon: '📤' },
  email_received: { label: '이메일 수신', icon: '📥' },
  meeting: { label: '미팅', icon: '🤝' },
  note: { label: '메모', icon: '📝' },
  stage_change: { label: '단계 변경', icon: '➡️' },
  proposal_sent: { label: '제안서 발송', icon: '📄' },
  contract_sent: { label: '계약서 발송', icon: '📋' },
}

// 네비게이션 메뉴
export const NAV_ITEMS = [
  { href: '/dashboard', label: '대시보드', icon: 'LayoutDashboard' },
  { 
    href: '/clients', 
    label: '고객관리', 
    icon: 'Users',
    children: [
      { href: '/clients', label: '전체 목록' },
      { href: '/clients/kanban', label: '칸반 보드' },
    ]
  },
  { 
    href: '/email', 
    label: '이메일', 
    icon: 'Mail',
    children: [
      { href: '/email/compose', label: '발송' },
      { href: '/email/templates', label: '템플릿' },
    ]
  },
  { href: '/proposals', label: '제안서', icon: 'FileText' },
  { 
    href: '/analytics', 
    label: '분석', 
    icon: 'BarChart3',
    children: [
      { href: '/analytics/failure', label: '실패 분석' },
      { href: '/analytics/reports', label: '리포트' },
    ]
  },
  { href: '/settings', label: '설정', icon: 'Settings' },
]
